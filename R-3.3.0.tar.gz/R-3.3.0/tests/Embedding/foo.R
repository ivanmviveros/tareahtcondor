foo <-
function(...)
{
    args <- list(...)
    print(args)
    print(names(args))
    TRUE
}
